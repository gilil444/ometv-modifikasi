# OmeTV Connection Check (Android companion)

A small Android utility that reports device-level camera permission/availability and Android network status. It does **not** modify OmeTV, disable face checks, conceal activity, or bypass platform moderation.

## Build

1. Open this folder in Android Studio (Giraffe or newer; Android Gradle Plugin 8.7.3).
2. Allow Android Studio to install the required Android SDK Platform 35 and Gradle components.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated debug APK on an Android 6.0+ device.
5. Open the app, grant camera permission, and tap **Run diagnostics**.

## What it checks

- Runtime camera permission.
- Camera IDs and front/back lens facing, using Android Camera2 metadata.
- Camera availability notifications while the app is open.
- Active network, internet/validated capabilities, transport, and metered status.
- Network availability/loss events while the app is open.

## Limitations

- It does not open or stream the camera; it only checks device-level camera metadata and availability.
- It cannot determine why OmeTV accepts/rejects a session or inspect server-side moderation.
- It is a companion app, not a patched OmeTV APK. The original APK is left untouched.
