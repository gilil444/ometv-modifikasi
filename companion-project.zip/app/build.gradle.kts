plugins { id("com.android.application") }

android {
    namespace = "com.roseeni.ometvcompanion"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.roseeni.ometvcompanion"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
