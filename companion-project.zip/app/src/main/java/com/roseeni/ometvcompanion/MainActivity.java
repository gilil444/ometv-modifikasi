package com.roseeni.ometvcompanion;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Typeface;

import java.text.DateFormat;
import java.util.Date;

/** Local diagnostics only: this app does not connect to, alter, or evade OmeTV moderation. */
public final class MainActivity extends Activity {
    private static final int CAMERA_PERMISSION_REQUEST = 42;
    private TextView report;
    private CameraManager cameraManager;
    private ConnectivityManager connectivityManager;
    private CameraManager.AvailabilityCallback cameraCallback;
    private ConnectivityManager.NetworkCallback networkCallback;
    private final StringBuilder events = new StringBuilder();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        buildUi();
        registerObservers();
        refresh();
    }

    private void buildUi() {
        int pad = dp(18);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFFF5F7FA);

        TextView heading = new TextView(this);
        heading.setText("OmeTV Connection Check");
        heading.setTextSize(23);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setTextColor(0xFF172033);
        root.addView(heading);

        TextView sub = new TextView(this);
        sub.setText("Local camera and network diagnostics • no moderation changes");
        sub.setTextSize(13);
        sub.setTextColor(0xFF536174);
        sub.setPadding(0, dp(6), 0, dp(14));
        root.addView(sub);

        Button permission = new Button(this);
        permission.setText("Grant camera permission");
        permission.setOnClickListener(v -> requestCameraPermission());
        root.addView(permission);

        Button refresh = new Button(this);
        refresh.setText("Run diagnostics");
        refresh.setOnClickListener(v -> refresh());
        root.addView(refresh);

        ScrollView scroll = new ScrollView(this);
        report = new TextView(this);
        report.setTextSize(14);
        report.setTextColor(0xFF172033);
        report.setTypeface(Typeface.MONOSPACE);
        report.setMovementMethod(new ScrollingMovementMethod());
        report.setPadding(dp(12), dp(12), dp(12), dp(12));
        report.setBackgroundColor(0xFFFFFFFF);
        scroll.addView(report);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 1f);
        lp.topMargin = dp(12);
        root.addView(scroll, lp);
        setContentView(root);
    }

    private void requestCameraPermission() {
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            refresh();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == CAMERA_PERMISSION_REQUEST) refresh();
    }

    private void registerObservers() {
        if (cameraManager != null) {
            cameraCallback = new CameraManager.AvailabilityCallback() {
                @Override public void onCameraAvailable(String id) { addEvent("Camera available: " + id); }
                @Override public void onCameraUnavailable(String id) { addEvent("Camera busy/unavailable: " + id); }
            };
            cameraManager.registerAvailabilityCallback(cameraCallback, null);
        }
        if (connectivityManager != null) {
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) { addEvent("Network became available"); }
                @Override public void onLost(Network network) { addEvent("Network connection lost"); }
                @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                    addEvent("Network capabilities changed: " + describeTransport(caps));
                }
            };
            try {
                if (Build.VERSION.SDK_INT >= 24) connectivityManager.registerDefaultNetworkCallback(networkCallback);
                else connectivityManager.registerNetworkCallback(new NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), networkCallback);
            } catch (RuntimeException ex) { addEvent("Network monitor unavailable: " + ex.getClass().getSimpleName()); }
        }
    }

    private void refresh() {
        StringBuilder out = new StringBuilder();
        out.append("CHECK TIME: ").append(DateFormat.getDateTimeInstance().format(new Date())).append("\n\n");
        boolean granted = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        out.append("CAMERA PERMISSION: ").append(granted ? "GRANTED" : "NOT GRANTED").append("\n");
        if (granted && cameraManager != null) {
            try {
                String[] ids = cameraManager.getCameraIdList();
                out.append("CAMERAS FOUND: ").append(ids.length).append("\n");
                for (String id : ids) {
                    CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
                    Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                    String lens = facing == null ? "unknown" : facing == CameraCharacteristics.LENS_FACING_FRONT ? "front" : facing == CameraCharacteristics.LENS_FACING_BACK ? "back" : "external/other";
                    out.append("  • Camera ").append(id).append(" — ").append(lens).append("\n");
                }
            } catch (CameraAccessException | SecurityException ex) {
                out.append("CAMERA ERROR: ").append(ex.getClass().getSimpleName()).append(" — ").append(ex.getMessage()).append("\n");
            }
        } else {
            out.append("Grant camera permission to enumerate available cameras.\n");
        }

        out.append("\nNETWORK:\n");
        Network active = connectivityManager == null ? null : connectivityManager.getActiveNetwork();
        NetworkCapabilities caps = active == null ? null : connectivityManager.getNetworkCapabilities(active);
        if (caps == null) {
            out.append("  No active network detected\n");
        } else {
            out.append("  Internet capability: ").append(caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ? "yes" : "no").append("\n");
            out.append("  Validated by Android: ").append(caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ? "yes" : "no").append("\n");
            out.append("  Transport: ").append(describeTransport(caps)).append("\n");
            out.append("  Metered: ").append(connectivityManager.isActiveNetworkMetered() ? "yes" : "no").append("\n");
        }
        out.append("\nLIVE EVENTS (latest first):\n");
        out.append(events.length() == 0 ? "  No events yet\n" : events);
        out.append("\nNOTE: This tool checks device-level conditions only. It cannot inspect OmeTV's server-side decisions or guarantee a call will connect.\n");
        report.setText(out.toString());
    }

    private String describeTransport(NetworkCapabilities c) {
        if (c == null) return "unknown";
        StringBuilder s = new StringBuilder();
        if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) s.append("Wi-Fi ");
        if (c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) s.append("cellular ");
        if (c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) s.append("Ethernet ");
        if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) s.append("VPN ");
        return s.length() == 0 ? "other/unknown" : s.toString().trim();
    }

    private void addEvent(String event) {
        runOnUiThread(() -> {
            events.insert(0, DateFormat.getTimeInstance().format(new Date()) + "  " + event + "\n");
            if (events.length() > 5000) events.setLength(5000);
            refresh();
        });
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (cameraManager != null && cameraCallback != null) cameraManager.unregisterAvailabilityCallback(cameraCallback);
        if (connectivityManager != null && networkCallback != null) {
            try { connectivityManager.unregisterNetworkCallback(networkCallback); } catch (RuntimeException ignored) { }
        }
    }
}
